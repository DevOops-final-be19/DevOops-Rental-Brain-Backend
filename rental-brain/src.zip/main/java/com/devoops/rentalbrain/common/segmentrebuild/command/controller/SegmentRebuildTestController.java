package com.devoops.rentalbrain.common.segmentrebuild.command.controller;

import com.devoops.rentalbrain.common.segmentrebuild.command.service.SegmentRebuildBatchService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/segmentrebuild")
public class SegmentRebuildTestController {

    private final SegmentRebuildBatchService segmentRebuildBatchService;

    @PostMapping("/run")
    public ResponseEntity<Map<String, Object>> runOnce() {
        int u1 = segmentRebuildBatchService.fixPotentialToNew();
        int u2 = segmentRebuildBatchService.fixNewToNormalWithHistory();
        int u3 = segmentRebuildBatchService.fixNormalToVipWithHistory();
        int u4 = segmentRebuildBatchService.fixToRiskWithHistory();
        int u5  = segmentRebuildBatchService.fixRiskToBlacklistWithHistory();

        return ResponseEntity.ok(Map.of(
                "potentialToNewUpdated", u1,
                "newToNormalUpdated", u2,
                "normalToVipUpdated", u3,
                "toRiskUpdated", u4,
                "riskToBlacklist", u5
        ));
    }
}
