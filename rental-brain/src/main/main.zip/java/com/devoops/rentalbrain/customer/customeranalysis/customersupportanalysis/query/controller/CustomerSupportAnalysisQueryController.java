package com.devoops.rentalbrain.customer.customeranalysis.customersupportanalysis.query.controller;


import com.devoops.rentalbrain.customer.customeranalysis.customersupportanalysis.query.dto.CustomerSupportAnalysisQueryResponseKPIDTO;
import com.devoops.rentalbrain.customer.customeranalysis.customersupportanalysis.query.service.CustomerSupportAnalysisQueryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/customerSupportAnalysis")
@Slf4j
public class CustomerSupportAnalysisQueryController {

    private final CustomerSupportAnalysisQueryService customerSupportAnalysisQueryService;

    @Autowired
    public CustomerSupportAnalysisQueryController(CustomerSupportAnalysisQueryService customerSupportAnalysisQueryService) {
        this.customerSupportAnalysisQueryService = customerSupportAnalysisQueryService;
    }


    // 고객 응대 분석 kpi
    @GetMapping("/kpi")
    public CustomerSupportAnalysisQueryResponseKPIDTO getKpi(
            @RequestParam String month
    ) {
        return customerSupportAnalysisQueryService.getKpi(month);
    }
}
