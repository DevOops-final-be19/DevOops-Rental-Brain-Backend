package com.devoops.rentalbrain.common.ai.command.dto;

public class EmbeddingDTO {
}
