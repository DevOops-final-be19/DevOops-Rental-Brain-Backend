package com.devoops.rentalbrain.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;


//MyBatis Mapper 스캔 설정(단어 임베딩에 사용중)
@Configuration
@MapperScan(basePackages = {
        "com.devoops.rentalbrain.**.query.mapper",   // 너희 규칙대로 mapper만
        "com.devoops.rentalbrain.**.command.mapper"  // (있다면)
})
public class MyBatisMapperScanConfig {
}